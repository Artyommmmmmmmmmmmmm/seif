package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btn;
    View hide;
    View auto;
    Button slidebtn;
    View slider;
    String hcheck = "hidden";
    int sliderCheck = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        auto = findViewById(R.id.auto);
        auto.setBackgroundColor(Color.argb(255, 0, 255, 0));
        btn = findViewById(R.id.button1);
        hide = findViewById(R.id.viewhide);
        hide.setBackgroundColor(Color.argb(255, 0, 255, 0));
        slider = findViewById(R.id.slider);
        slider.setBackgroundColor(Color.argb(255, 0, 255, 0));
        slidebtn = findViewById(R.id.buttonslide);
        slidebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hidden = hide.getVisibility();
                if (hide.getVisibility() == View.INVISIBLE) {
                    hide.setVisibility(View.VISIBLE);
                } else if (hide.getVisibility() == View.VISIBLE ) {
                    hide.setVisibility(View.INVISIBLE);
                }
            }
        });
        slidebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sliderCheck == 1) {
                    slider.animate()
                            .translationY(0)
                            .setDuration(300)
                            .start();
                    sliderCheck = 2;
                } else if (sliderCheck == 2) {
                    slider.animate()
                            .translationY(300)
                            .setDuration(300)
                            .start();
                    sliderCheck = 1;
                }
            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}